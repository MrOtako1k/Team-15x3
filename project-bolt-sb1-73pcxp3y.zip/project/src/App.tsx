import React from 'react';
import AdminDashboard from './components/AdminDashboard';

function App() {
  return <AdminDashboard />;
}

export default App;
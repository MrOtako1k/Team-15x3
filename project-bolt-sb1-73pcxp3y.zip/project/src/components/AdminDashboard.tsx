import React, { useState, useEffect, useRef } from 'react';
import { 
  Users, 
  MessageSquare, 
  Shield, 
  Activity, 
  Eye, 
  Terminal, 
  Wifi, 
  WifiOff, 
  Clock, 
  Globe,
  Server,
  Database,
  Lock,
  Unlock,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Send,
  Settings,
  UserCheck,
  UserX,
  Zap,
  Code,
  Monitor
} from 'lucide-react';

interface User {
  id: string;
  name: string;
  role: 'admin' | 'tester' | 'developer' | 'analyst' | 'visitor';
  status: 'online' | 'offline' | 'busy';
  lastSeen: string;
  ip: string;
  location: string;
  device: string;
}

interface ChatMessage {
  id: string;
  user: string;
  message: string;
  timestamp: string;
  type: 'user' | 'admin' | 'system';
}

interface SystemLog {
  id: string;
  type: 'info' | 'warning' | 'error' | 'success';
  message: string;
  timestamp: string;
  user?: string;
}

const AdminDashboard: React.FC = () => {
  const [users, setUsers] = useState<User[]>([
    { id: '1', name: 'أحمد محمد', role: 'admin', status: 'online', lastSeen: 'الآن', ip: '192.168.1.100', location: 'الرياض', device: 'Chrome/Windows' },
    { id: '2', name: 'سارة أحمد', role: 'admin', status: 'online', lastSeen: 'الآن', ip: '192.168.1.101', location: 'جدة', device: 'Firefox/Mac' },
    { id: '3', name: 'محمد علي', role: 'tester', status: 'busy', lastSeen: '5 دقائق', ip: '192.168.1.102', location: 'الدمام', device: 'Safari/iPhone' },
    { id: '4', name: 'فاطمة حسن', role: 'developer', status: 'online', lastSeen: 'الآن', ip: '192.168.1.103', location: 'الرياض', device: 'Chrome/Linux' },
    { id: '5', name: 'يوسف خالد', role: 'visitor', status: 'online', lastSeen: 'الآن', ip: '203.45.67.89', location: 'القاهرة', device: 'Chrome/Android' },
    { id: '6', name: 'مريم أحمد', role: 'visitor', status: 'online', lastSeen: '2 دقائق', ip: '185.23.45.67', location: 'دبي', device: 'Edge/Windows' },
    { id: '7', name: 'خالد محمود', role: 'analyst', status: 'offline', lastSeen: '30 دقيقة', ip: '192.168.1.104', location: 'الكويت', device: 'Chrome/Windows' }
  ]);

  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    { id: '1', user: 'النظام', message: 'مرحباً بكم في لوحة تحكم الأدمين', timestamp: '14:30', type: 'system' },
    { id: '2', user: 'يوسف خالد', message: 'مرحباً، أحتاج مساعدة في فهم خدماتكم', timestamp: '14:32', type: 'user' },
    { id: '3', user: 'أحمد محمد', message: 'أهلاً وسهلاً، سأساعدك بكل سرور', timestamp: '14:33', type: 'admin' }
  ]);

  const [systemLogs, setSystemLogs] = useState<SystemLog[]>([
    { id: '1', type: 'success', message: 'تم تسجيل دخول مستخدم جديد: يوسف خالد', timestamp: '14:30', user: 'يوسف خالد' },
    { id: '2', type: 'info', message: 'تم تحديث إعدادات النظام', timestamp: '14:25', user: 'أحمد محمد' },
    { id: '3', type: 'warning', message: 'محاولة دخول مشبوهة من IP: 45.67.89.123', timestamp: '14:20' },
    { id: '4', type: 'error', message: 'فشل في الاتصال بقاعدة البيانات', timestamp: '14:15' },
    { id: '5', type: 'success', message: 'تم إنشاء نسخة احتياطية بنجاح', timestamp: '14:10' }
  ]);

  const [newMessage, setNewMessage] = useState('');
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'chat' | 'logs' | 'security'>('overview');
  const chatEndRef = useRef<HTMLDivElement>(null);

  const stats = {
    totalUsers: users.length,
    onlineUsers: users.filter(u => u.status === 'online').length,
    visitors: users.filter(u => u.role === 'visitor').length,
    admins: users.filter(u => u.role === 'admin').length,
    activeChats: 3,
    systemHealth: 98
  };

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  useEffect(() => {
    // Simulate real-time updates
    const interval = setInterval(() => {
      // Update user statuses randomly
      setUsers(prev => prev.map(user => ({
        ...user,
        status: Math.random() > 0.9 ? 
          (user.status === 'online' ? 'busy' : 'online') : 
          user.status
      })));

      // Add random system logs
      if (Math.random() > 0.95) {
        const logTypes: SystemLog['type'][] = ['info', 'warning', 'success'];
        const messages = [
          'تم تحديث بيانات المستخدم',
          'نشاط مشبوه تم رصده',
          'تم إنجاز مهمة بنجاح',
          'تحديث أمني جديد'
        ];
        
        const newLog: SystemLog = {
          id: Date.now().toString(),
          type: logTypes[Math.floor(Math.random() * logTypes.length)],
          message: messages[Math.floor(Math.random() * messages.length)],
          timestamp: new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' })
        };
        
        setSystemLogs(prev => [newLog, ...prev.slice(0, 9)]);
      }
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const sendMessage = () => {
    if (newMessage.trim()) {
      const message: ChatMessage = {
        id: Date.now().toString(),
        user: 'أحمد محمد (أدمين)',
        message: newMessage,
        timestamp: new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' }),
        type: 'admin'
      };
      setChatMessages(prev => [...prev, message]);
      setNewMessage('');
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'admin': return 'bg-red-500';
      case 'tester': return 'bg-blue-500';
      case 'developer': return 'bg-green-500';
      case 'analyst': return 'bg-purple-500';
      case 'visitor': return 'bg-orange-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'text-green-400';
      case 'busy': return 'text-yellow-400';
      case 'offline': return 'text-gray-400';
      default: return 'text-gray-400';
    }
  };

  const getLogIcon = (type: string) => {
    switch (type) {
      case 'success': return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-yellow-400" />;
      case 'error': return <XCircle className="w-4 h-4 text-red-400" />;
      default: return <Activity className="w-4 h-4 text-blue-400" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black text-white" dir="rtl">
      {/* Header */}
      <header className="bg-black/50 backdrop-blur-lg border-b border-gray-700/50 p-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4 space-x-reverse">
            <div className="flex items-center space-x-2 space-x-reverse">
              <Shield className="w-8 h-8 text-cyan-400" />
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
                  TEST Team 15x3
                </h1>
                <p className="text-sm text-gray-400">لوحة تحكم الأدمين</p>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-4 space-x-reverse">
            <div className="flex items-center space-x-2 space-x-reverse text-sm">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-green-400">النظام يعمل بكفاءة {stats.systemHealth}%</span>
            </div>
            <Settings className="w-6 h-6 text-gray-400 hover:text-white cursor-pointer transition-colors" />
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-black/30 backdrop-blur-lg border-b border-gray-700/30">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex space-x-8 space-x-reverse">
            {[
              { id: 'overview', label: 'نظرة عامة', icon: Monitor },
              { id: 'users', label: 'المستخدمين', icon: Users },
              { id: 'chat', label: 'الدردشة', icon: MessageSquare },
              { id: 'logs', label: 'سجل النظام', icon: Terminal },
              { id: 'security', label: 'الأمان', icon: Lock }
            ].map(tab => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center space-x-2 space-x-reverse px-4 py-3 border-b-2 transition-colors ${
                    activeTab === tab.id
                      ? 'border-cyan-400 text-cyan-400'
                      : 'border-transparent text-gray-400 hover:text-white'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto p-6">
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { label: 'إجمالي المستخدمين', value: stats.totalUsers, icon: Users, color: 'from-blue-500 to-cyan-500' },
                { label: 'متصل الآن', value: stats.onlineUsers, icon: Wifi, color: 'from-green-500 to-emerald-500' },
                { label: 'الزوار', value: stats.visitors, icon: Eye, color: 'from-orange-500 to-red-500' },
                { label: 'المحادثات النشطة', value: stats.activeChats, icon: MessageSquare, color: 'from-purple-500 to-pink-500' }
              ].map((stat, index) => {
                const Icon = stat.icon;
                return (
                  <div key={index} className="bg-gray-800/50 backdrop-blur-lg rounded-xl p-6 border border-gray-700/50">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-400 text-sm">{stat.label}</p>
                        <p className="text-3xl font-bold text-white mt-1">{stat.value}</p>
                      </div>
                      <div className={`p-3 rounded-lg bg-gradient-to-r ${stat.color}`}>
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Real-time Activity */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-gray-800/50 backdrop-blur-lg rounded-xl p-6 border border-gray-700/50">
                <h3 className="text-xl font-bold mb-4 flex items-center space-x-2 space-x-reverse">
                  <Activity className="w-6 h-6 text-cyan-400" />
                  <span>النشاط المباشر</span>
                </h3>
                <div className="space-y-3">
                  {systemLogs.slice(0, 5).map(log => (
                    <div key={log.id} className="flex items-center space-x-3 space-x-reverse p-3 bg-gray-900/50 rounded-lg">
                      {getLogIcon(log.type)}
                      <div className="flex-1">
                        <p className="text-sm text-white">{log.message}</p>
                        <p className="text-xs text-gray-400">{log.timestamp}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-gray-800/50 backdrop-blur-lg rounded-xl p-6 border border-gray-700/50">
                <h3 className="text-xl font-bold mb-4 flex items-center space-x-2 space-x-reverse">
                  <Globe className="w-6 h-6 text-green-400" />
                  <span>المستخدمين المتصلين</span>
                </h3>
                <div className="space-y-3">
                  {users.filter(u => u.status === 'online').slice(0, 5).map(user => (
                    <div key={user.id} className="flex items-center space-x-3 space-x-reverse p-3 bg-gray-900/50 rounded-lg">
                      <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                      <div className="flex-1">
                        <p className="text-sm text-white font-medium">{user.name}</p>
                        <p className="text-xs text-gray-400">{user.location} • {user.device}</p>
                      </div>
                      <span className={`px-2 py-1 rounded-full text-xs ${getRoleColor(user.role)} text-white`}>
                        {user.role}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'users' && (
          <div className="space-y-6">
            <div className="bg-gray-800/50 backdrop-blur-lg rounded-xl border border-gray-700/50 overflow-hidden">
              <div className="p-6 border-b border-gray-700/50">
                <h3 className="text-xl font-bold flex items-center space-x-2 space-x-reverse">
                  <Users className="w-6 h-6 text-blue-400" />
                  <span>إدارة المستخدمين</span>
                </h3>
              </div>
              
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-900/50">
                    <tr>
                      <th className="px-6 py-3 text-right text-xs font-medium text-gray-400 uppercase tracking-wider">المستخدم</th>
                      <th className="px-6 py-3 text-right text-xs font-medium text-gray-400 uppercase tracking-wider">الدور</th>
                      <th className="px-6 py-3 text-right text-xs font-medium text-gray-400 uppercase tracking-wider">الحالة</th>
                      <th className="px-6 py-3 text-right text-xs font-medium text-gray-400 uppercase tracking-wider">الموقع</th>
                      <th className="px-6 py-3 text-right text-xs font-medium text-gray-400 uppercase tracking-wider">IP</th>
                      <th className="px-6 py-3 text-right text-xs font-medium text-gray-400 uppercase tracking-wider">الجهاز</th>
                      <th className="px-6 py-3 text-right text-xs font-medium text-gray-400 uppercase tracking-wider">الإجراءات</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-700/50">
                    {users.map(user => (
                      <tr key={user.id} className="hover:bg-gray-700/30 transition-colors">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center space-x-3 space-x-reverse">
                            <div className={`w-3 h-3 rounded-full ${user.status === 'online' ? 'bg-green-400' : user.status === 'busy' ? 'bg-yellow-400' : 'bg-gray-400'}`}></div>
                            <div>
                              <div className="text-sm font-medium text-white">{user.name}</div>
                              <div className="text-sm text-gray-400">آخر ظهور: {user.lastSeen}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 py-1 rounded-full text-xs ${getRoleColor(user.role)} text-white`}>
                            {user.role}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className={`flex items-center space-x-1 space-x-reverse ${getStatusColor(user.status)}`}>
                            {user.status === 'online' ? <Wifi className="w-4 h-4" /> : <WifiOff className="w-4 h-4" />}
                            <span className="text-sm">{user.status}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">{user.location}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300 font-mono">{user.ip}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">{user.device}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <div className="flex space-x-2 space-x-reverse">
                            <button className="text-blue-400 hover:text-blue-300 transition-colors">
                              <UserCheck className="w-4 h-4" />
                            </button>
                            <button className="text-red-400 hover:text-red-300 transition-colors">
                              <UserX className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'chat' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <div className="bg-gray-800/50 backdrop-blur-lg rounded-xl border border-gray-700/50 h-96 flex flex-col">
                <div className="p-4 border-b border-gray-700/50">
                  <h3 className="text-lg font-bold flex items-center space-x-2 space-x-reverse">
                    <MessageSquare className="w-5 h-5 text-green-400" />
                    <span>دردشة المستخدمين</span>
                  </h3>
                </div>
                
                <div className="flex-1 overflow-y-auto p-4 space-y-3">
                  {chatMessages.map(message => (
                    <div key={message.id} className={`flex ${message.type === 'admin' ? 'justify-end' : 'justify-start'}`}>
                      <div className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                        message.type === 'admin' 
                          ? 'bg-blue-600 text-white' 
                          : message.type === 'system'
                          ? 'bg-gray-700 text-gray-300'
                          : 'bg-gray-600 text-white'
                      }`}>
                        <div className="text-sm font-medium mb-1">{message.user}</div>
                        <div className="text-sm">{message.message}</div>
                        <div className="text-xs opacity-70 mt-1">{message.timestamp}</div>
                      </div>
                    </div>
                  ))}
                  <div ref={chatEndRef} />
                </div>
                
                <div className="p-4 border-t border-gray-700/50">
                  <div className="flex space-x-2 space-x-reverse">
                    <input
                      type="text"
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                      placeholder="اكتب رسالتك..."
                      className="flex-1 bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                    />
                    <button
                      onClick={sendMessage}
                      className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="bg-gray-800/50 backdrop-blur-lg rounded-xl p-4 border border-gray-700/50">
                <h4 className="font-bold mb-3 text-cyan-400">المستخدمين النشطين</h4>
                <div className="space-y-2">
                  {users.filter(u => u.status === 'online').map(user => (
                    <div key={user.id} className="flex items-center space-x-2 space-x-reverse p-2 bg-gray-700/50 rounded-lg">
                      <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                      <span className="text-sm text-white">{user.name}</span>
                      <span className={`px-1 py-0.5 rounded text-xs ${getRoleColor(user.role)} text-white`}>
                        {user.role}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'logs' && (
          <div className="space-y-6">
            <div className="bg-gray-800/50 backdrop-blur-lg rounded-xl border border-gray-700/50">
              <div className="p-6 border-b border-gray-700/50">
                <h3 className="text-xl font-bold flex items-center space-x-2 space-x-reverse">
                  <Terminal className="w-6 h-6 text-green-400" />
                  <span>سجل النظام</span>
                </h3>
              </div>
              
              <div className="p-6">
                <div className="space-y-3">
                  {systemLogs.map(log => (
                    <div key={log.id} className="flex items-center space-x-4 space-x-reverse p-4 bg-gray-900/50 rounded-lg border border-gray-700/30">
                      {getLogIcon(log.type)}
                      <div className="flex-1">
                        <p className="text-white text-sm">{log.message}</p>
                        <div className="flex items-center space-x-2 space-x-reverse text-xs text-gray-400 mt-1">
                          <Clock className="w-3 h-3" />
                          <span>{log.timestamp}</span>
                          {log.user && (
                            <>
                              <span>•</span>
                              <span>{log.user}</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'security' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-gray-800/50 backdrop-blur-lg rounded-xl p-6 border border-gray-700/50">
                <h3 className="text-xl font-bold mb-4 flex items-center space-x-2 space-x-reverse">
                  <Shield className="w-6 h-6 text-red-400" />
                  <span>حالة الأمان</span>
                </h3>
                <div className="space-y-4">
                  {[
                    { label: 'جدار الحماية', status: 'نشط', icon: Shield, color: 'text-green-400' },
                    { label: 'كشف التسلل', status: 'نشط', icon: Eye, color: 'text-green-400' },
                    { label: 'تشفير البيانات', status: 'مفعل', icon: Lock, color: 'text-green-400' },
                    { label: 'مراقبة الشبكة', status: 'نشط', icon: Activity, color: 'text-green-400' }
                  ].map((item, index) => {
                    const Icon = item.icon;
                    return (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-900/50 rounded-lg">
                        <div className="flex items-center space-x-3 space-x-reverse">
                          <Icon className={`w-5 h-5 ${item.color}`} />
                          <span className="text-white">{item.label}</span>
                        </div>
                        <span className={`text-sm ${item.color}`}>{item.status}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="bg-gray-800/50 backdrop-blur-lg rounded-xl p-6 border border-gray-700/50">
                <h3 className="text-xl font-bold mb-4 flex items-center space-x-2 space-x-reverse">
                  <AlertTriangle className="w-6 h-6 text-yellow-400" />
                  <span>تنبيهات أمنية</span>
                </h3>
                <div className="space-y-3">
                  {[
                    { type: 'warning', message: 'محاولة دخول مشبوهة من IP خارجي', time: '5 دقائق' },
                    { type: 'info', message: 'تم تحديث كلمة مرور المستخدم', time: '15 دقيقة' },
                    { type: 'error', message: 'فشل في المصادقة الثنائية', time: '30 دقيقة' }
                  ].map((alert, index) => (
                    <div key={index} className="flex items-center space-x-3 space-x-reverse p-3 bg-gray-900/50 rounded-lg">
                      {getLogIcon(alert.type)}
                      <div className="flex-1">
                        <p className="text-sm text-white">{alert.message}</p>
                        <p className="text-xs text-gray-400">منذ {alert.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="bg-gray-800/50 backdrop-blur-lg rounded-xl p-6 border border-gray-700/50">
              <h3 className="text-xl font-bold mb-4 flex items-center space-x-2 space-x-reverse">
                <Code className="w-6 h-6 text-cyan-400" />
                <span>أدوات الهكر الأخلاقي</span>
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[
                  { name: 'فحص الثغرات', status: 'جاهز', icon: Zap },
                  { name: 'اختبار الاختراق', status: 'قيد التشغيل', icon: Terminal },
                  { name: 'مراقبة الشبكة', status: 'نشط', icon: Activity }
                ].map((tool, index) => {
                  const Icon = tool.icon;
                  return (
                    <div key={index} className="bg-gray-900/50 p-4 rounded-lg border border-gray-700/30">
                      <div className="flex items-center space-x-2 space-x-reverse mb-2">
                        <Icon className="w-5 h-5 text-cyan-400" />
                        <span className="text-white font-medium">{tool.name}</span>
                      </div>
                      <p className="text-sm text-gray-400">{tool.status}</p>
                      <button className="mt-2 bg-cyan-600 hover:bg-cyan-700 text-white px-3 py-1 rounded text-sm transition-colors">
                        تشغيل
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default AdminDashboard;